package com.surya.meowsic.presentation.player

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.surya.meowsic.domain.Song
import com.surya.meowsic.ui.components.ObsidianDivider
import com.surya.meowsic.ui.components.ObsidianSquareArtwork
import com.surya.meowsic.ui.theme.LiquidGlassTokens
import com.surya.meowsic.ui.theme.Obsidian

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QueueBottomSheet(
    queue: List<Song>,
    currentIndex: Int,
    palette: LiquidGlassTokens.AmbientPalette,
    onSongClick: (Song) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Obsidian.SurfacePrimary,
        scrimColor = Color.Black.copy(alpha = 0.72f),
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 12.dp)
                    .width(36.dp)
                    .height(4.dp)
                    .clip(CircleShape)
                    .background(Obsidian.GlassBorder)
            )
        },
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = Obsidian.SpacingLg.dp)
                .padding(bottom = 32.dp)
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Up Next",
                    color = Obsidian.TextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${queue.size} Tracks",
                    color = Obsidian.TextTertiary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Normal
                )
            }

            ObsidianDivider()
            Spacer(modifier = Modifier.height(Obsidian.SpacingXs.dp))

            if (queue.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Queue is empty",
                        color = Obsidian.TextTertiary,
                        fontSize = 15.sp
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 440.dp),
                    verticalArrangement = Arrangement.spacedBy(0.dp)
                ) {
                    itemsIndexed(
                        items = queue,
                        key = { index, song -> "${song.id}_$index" }
                    ) { index, song ->
                        val isCurrent = index == currentIndex

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = null,
                                    onClick = { onSongClick(song) }
                                )
                                .background(
                                    if (isCurrent) Obsidian.SurfaceHighlight else Color.Transparent
                                )
                                .padding(
                                    horizontal = Obsidian.SpacingXs.dp,
                                    vertical = Obsidian.SpacingSm.dp
                                ),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            ObsidianSquareArtwork(
                                imageUrl = song.thumbnailUrl,
                                size = 44.dp,
                                cornerRadius = 8.dp,
                                contentDescription = song.title
                            )

                            Spacer(modifier = Modifier.width(Obsidian.SpacingSm.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = song.title,
                                    color = if (isCurrent) Obsidian.TextPrimary else Obsidian.TextSecondary,
                                    fontSize = 14.sp,
                                    fontWeight = if (isCurrent) FontWeight.SemiBold else FontWeight.Normal,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = song.artist,
                                    color = Obsidian.TextTertiary,
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            if (isCurrent) {
                                Icon(
                                    imageVector = Icons.Default.Equalizer,
                                    contentDescription = "Currently Playing",
                                    tint = Obsidian.IconTintActive,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        if (index < queue.size - 1) {
                            ObsidianDivider(
                                modifier = Modifier.padding(horizontal = Obsidian.SpacingXs.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
