package com.surya.meowsic.presentation.player

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.surya.meowsic.presentation.search.RepeatMode
import com.surya.meowsic.presentation.search.SearchViewModel
import com.surya.meowsic.ui.components.AmbientLightOrbs
import com.surya.meowsic.ui.theme.LiquidGlassTokens
import com.surya.meowsic.ui.theme.Obsidian
import java.util.Locale

@Composable
fun FullScreenPlayer(
    viewModel: SearchViewModel,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentSong by viewModel.currentSong.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val isResolving by viewModel.isResolving.collectAsState()
    val isBuffering by viewModel.isBuffering.collectAsState()
    val position by viewModel.playbackPosition.collectAsState()
    val duration by viewModel.duration.collectAsState()
    val repeatMode by viewModel.repeatMode.collectAsState()
    val isShuffle by viewModel.isShuffle.collectAsState()
    val queue by viewModel.queue.collectAsState()
    val currentIndex by viewModel.currentIndex.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()

    var isFavorite by remember { mutableStateOf(false) }
    var isQueueOpen by remember { mutableStateOf(false) }

    val song = currentSong ?: return

    // Dynamic ambient palette
    val palette = remember(song.id, song.title) {
        LiquidGlassTokens.getAmbientPaletteForSong(song.id + song.title)
    }

    // Artwork spring animation: 1.0f playing, 0.92f paused
    val artScale by animateFloatAsState(
        targetValue = if (isPlaying) 1.0f else 0.92f,
        animationSpec = LiquidGlassTokens.TactileSpringSpecFloat,
        label = "ArtworkScale"
    )
    val artAlpha by animateFloatAsState(
        targetValue = if (isPlaying) 1.0f else 0.78f,
        animationSpec = LiquidGlassTokens.TactileSpringSpecFloat,
        label = "ArtworkAlpha"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Obsidian.Background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // Localized ambient light emitters
        AmbientLightOrbs(
            palette = palette,
            opacity = 0.28f
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = Obsidian.SpacingXl.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // ------------------------------------------------
            // 1. TOP BAR
            // ------------------------------------------------
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Chevron down
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = onDismiss
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowDown,
                        contentDescription = "Collapse Player",
                        tint = Obsidian.IconTint,
                        modifier = Modifier.size(32.dp)
                    )
                }

                // Now Playing label
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "NOW PLAYING",
                        color = Obsidian.TextTertiary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.2.sp
                    )
                    if (queue.isNotEmpty() && currentIndex >= 0) {
                        Text(
                            text = "${currentIndex + 1} of ${queue.size}",
                            color = Obsidian.TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Normal
                        )
                    }
                }

                // Queue icon
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = { isQueueOpen = true }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.QueueMusic,
                        contentDescription = "Open Queue",
                        tint = if (isQueueOpen) Obsidian.IconTintActive else Obsidian.IconTint,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // ------------------------------------------------
            // 2. ARTWORK
            // ------------------------------------------------
            Box(
                modifier = Modifier
                    .fillMaxWidth(Obsidian.ArtworkWidthFraction)
                    .aspectRatio(1f)
                    .graphicsLayer {
                        scaleX = artScale
                        scaleY = artScale
                        alpha = artAlpha
                    }
                    .shadow(
                        elevation = 32.dp,
                        shape = RoundedCornerShape(Obsidian.ArtworkRadius.dp),
                        ambientColor = palette.primary.copy(alpha = 0.4f),
                        spotColor = palette.secondary.copy(alpha = 0.4f)
                    )
                    .clip(RoundedCornerShape(Obsidian.ArtworkRadius.dp))
                    .background(Obsidian.SurfaceSecondary),
                contentAlignment = Alignment.Center
            ) {
                if (song.thumbnailUrl.isNotBlank()) {
                    AsyncImage(
                        model = song.thumbnailUrl,
                        contentDescription = song.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.MusicNote,
                        contentDescription = null,
                        tint = Obsidian.TextTertiary,
                        modifier = Modifier.size(96.dp)
                    )
                }

                // Buffering / resolving overlay
                if (isResolving || isBuffering) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.55f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(
                                color = Obsidian.TextPrimary,
                                strokeWidth = 3.dp,
                                modifier = Modifier.size(42.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = if (isResolving) "Resolving stream..." else "Buffering...",
                                color = Obsidian.TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(Obsidian.SpacingXl.dp))

            // ------------------------------------------------
            // 3. SONG TITLE & ARTIST ROW
            // ------------------------------------------------
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = song.title,
                        color = Obsidian.TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = (-0.3).sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = song.artist,
                        color = Obsidian.TextSecondary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Normal,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = { isFavorite = !isFavorite }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = if (isFavorite) "Liked" else "Like",
                        tint = if (isFavorite) Obsidian.TextPrimary else Obsidian.IconTint,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(Obsidian.SpacingMd.dp))

            // ------------------------------------------------
            // 4. SEEK BAR + TIMESTAMPS
            // ------------------------------------------------
            LiquidScrubber(
                positionMs = position,
                durationMs = duration.coerceAtLeast(0L),
                palette = palette,
                onSeek = { seekPos -> viewModel.seekTo(seekPos) }
            )

            Spacer(modifier = Modifier.height(Obsidian.SpacingLg.dp))

            // ------------------------------------------------
            // 5. TRANSPORT CONTROLS
            // ------------------------------------------------
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 32.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Shuffle
                TactileIconButton(
                    onClick = { viewModel.toggleShuffle() },
                    isActive = isShuffle,
                    activeColor = Obsidian.TextPrimary,
                    icon = Icons.Default.Shuffle,
                    contentDescription = "Shuffle"
                )

                // Previous
                TactileIconButton(
                    onClick = { viewModel.playPrevious() },
                    icon = Icons.Default.SkipPrevious,
                    contentDescription = "Previous Song",
                    size = Obsidian.SkipButtonSize.dp,
                    iconSize = 36.dp
                )

                // Play / Pause — primary Obsidian orb
                val playInteraction = remember { MutableInteractionSource() }
                val isPlayPressed by playInteraction.collectIsPressedAsState()
                val playScale by animateFloatAsState(
                    targetValue = if (isPlayPressed) 0.92f else 1.0f,
                    animationSpec = LiquidGlassTokens.TactileSpringSpecFloat,
                    label = "PlayScale"
                )
                Box(
                    modifier = Modifier
                        .size(Obsidian.PlayButtonSize.dp)
                        .graphicsLayer {
                            scaleX = playScale
                            scaleY = playScale
                        }
                        .clip(CircleShape)
                        .background(Obsidian.TextPrimary)
                        .clickable(
                            interactionSource = playInteraction,
                            indication = null,
                            onClick = { viewModel.togglePlayPause() }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isResolving || isBuffering) {
                        CircularProgressIndicator(
                            color = Obsidian.Background,
                            strokeWidth = 3.dp,
                            modifier = Modifier.size(32.dp)
                        )
                    } else {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = Obsidian.Background,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }

                // Next
                TactileIconButton(
                    onClick = { viewModel.playNext() },
                    icon = Icons.Default.SkipNext,
                    contentDescription = "Next Song",
                    size = Obsidian.SkipButtonSize.dp,
                    iconSize = 36.dp
                )

                // Repeat
                TactileIconButton(
                    onClick = { viewModel.toggleRepeat() },
                    isActive = repeatMode != RepeatMode.OFF,
                    activeColor = Obsidian.TextPrimary,
                    icon = when (repeatMode) {
                        RepeatMode.ONE -> Icons.Default.RepeatOne
                        else -> Icons.Default.Repeat
                    },
                    contentDescription = "Repeat"
                )
            }

            // Error banner
            errorMessage?.let { error ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF1A0A0A))
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = error,
                        color = Color(0xFFCF6679),
                        fontSize = 12.sp,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = { viewModel.clearError() }) {
                        Text("Dismiss", color = Obsidian.TextSecondary, fontSize = 12.sp)
                    }
                }
            }
        }

        // Queue Bottom Sheet
        if (isQueueOpen) {
            QueueBottomSheet(
                queue = queue,
                currentIndex = currentIndex,
                palette = palette,
                onSongClick = { selectedSong ->
                    viewModel.playSong(selectedSong, playlist = queue)
                },
                onDismiss = { isQueueOpen = false }
            )
        }
    }
}

/**
 * Liquid Scrubber / Seek Bar (retained from original — palette-driven gradient)
 */
@Composable
fun LiquidScrubber(
    positionMs: Long,
    durationMs: Long,
    palette: LiquidGlassTokens.AmbientPalette,
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var isDragging by remember { mutableStateOf(false) }
    var dragProgress by remember { mutableFloatStateOf(0f) }
    var barWidthPx by remember { mutableFloatStateOf(1f) }

    val effectiveProgress = if (isDragging) {
        dragProgress
    } else if (durationMs > 0) {
        (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }

    val trackHeight by animateDpAsState(
        targetValue = if (isDragging) 10.dp else 6.dp,
        animationSpec = LiquidGlassTokens.TactileSpringSpecDp,
        label = "ScrubberHeight"
    )

    val thumbRadius by animateDpAsState(
        targetValue = if (isDragging) 9.dp else 0.dp,
        animationSpec = LiquidGlassTokens.TactileSpringSpecDp,
        label = "ThumbRadius"
    )

    val currentDisplayMs = if (isDragging && durationMs > 0) {
        (dragProgress * durationMs).toLong()
    } else {
        positionMs
    }

    Column(modifier = modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(28.dp)
                .onSizeChanged { barWidthPx = it.width.toFloat().coerceAtLeast(1f) }
                .pointerInput(durationMs) {
                    detectTapGestures { offset ->
                        if (durationMs > 0) {
                            val newProgress = (offset.x / barWidthPx).coerceIn(0f, 1f)
                            onSeek((newProgress * durationMs).toLong())
                        }
                    }
                }
                .pointerInput(durationMs) {
                    detectHorizontalDragGestures(
                        onDragStart = { offset ->
                            isDragging = true
                            dragProgress = (offset.x / barWidthPx).coerceIn(0f, 1f)
                        },
                        onDragEnd = {
                            if (durationMs > 0) {
                                onSeek((dragProgress * durationMs).toLong())
                            }
                            isDragging = false
                        },
                        onDragCancel = { isDragging = false },
                        onHorizontalDrag = { change, _ ->
                            change.consume()
                            dragProgress = (change.position.x / barWidthPx).coerceIn(0f, 1f)
                        }
                    )
                },
            contentAlignment = Alignment.CenterStart
        ) {
            Canvas(modifier = Modifier.fillMaxWidth().height(trackHeight)) {
                val cornerRadius = CornerRadius(size.height / 2f, size.height / 2f)

                drawRoundRect(
                    color = Color(0xFF454545),
                    size = size,
                    cornerRadius = cornerRadius
                )

                val fillWidth = size.width * effectiveProgress
                if (fillWidth > 0f) {
                    drawRoundRect(
                        brush = Brush.horizontalGradient(
                            colors = listOf(palette.primary, palette.secondary),
                            startX = 0f,
                            endX = size.width
                        ),
                        size = Size(fillWidth, size.height),
                        cornerRadius = cornerRadius
                    )

                    if (thumbRadius.toPx() > 0f) {
                        drawCircle(
                            color = Color.White,
                            radius = thumbRadius.toPx(),
                            center = Offset(fillWidth, size.height / 2f)
                        )
                        drawCircle(
                            color = palette.primary,
                            radius = thumbRadius.toPx() + 2.dp.toPx(),
                            center = Offset(fillWidth, size.height / 2f),
                            alpha = 0.5f
                        )
                    }
                }
            }
        }

        // Timestamps
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 2.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = formatTime(currentDisplayMs),
                color = Obsidian.TextTertiary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = formatTime(durationMs),
                color = Obsidian.TextTertiary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

/**
 * Tactile Secondary Transport Control (unchanged signature)
 */
@Composable
private fun TactileIconButton(
    onClick: () -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    modifier: Modifier = Modifier,
    size: androidx.compose.ui.unit.Dp = 44.dp,
    iconSize: androidx.compose.ui.unit.Dp = 24.dp,
    isActive: Boolean = false,
    activeColor: Color = Obsidian.TextPrimary
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.88f else 1.0f,
        animationSpec = LiquidGlassTokens.TactileSpringSpecFloat,
        label = "IconScale"
    )

    Box(
        modifier = modifier
            .size(size)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = if (isActive) activeColor else Obsidian.IconTint,
                modifier = Modifier.size(iconSize)
            )
            if (isActive) {
                Spacer(modifier = Modifier.height(3.dp))
                Box(
                    modifier = Modifier
                        .size(4.dp)
                        .clip(CircleShape)
                        .background(activeColor)
                )
            }
        }
    }
}

/**
 * Formats milliseconds into mm:ss timestamp string.
 */
fun formatTime(milliseconds: Long): String {
    if (milliseconds <= 0) return "00:00"
    val totalSeconds = milliseconds / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)
}
