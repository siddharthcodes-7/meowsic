package com.surya.meowsic.presentation.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.surya.meowsic.ui.components.ObsidianDivider
import com.surya.meowsic.ui.components.ObsidianGlassSurface
import com.surya.meowsic.ui.components.ObsidianSectionHeader
import com.surya.meowsic.ui.theme.Obsidian

@Composable
fun HomeScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Obsidian.Background)
            .statusBarsPadding()
    ) {
        // Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = Obsidian.SpacingXl.dp, vertical = Obsidian.SpacingMd.dp)
        ) {
            Text(
                text = "meowsic",
                color = Obsidian.TextPrimary,
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = (-0.5).sp
            )
            Spacer(modifier = Modifier.height(Obsidian.SpacingXxs.dp))
            Text(
                text = "Discover & play music.",
                color = Obsidian.TextSecondary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Normal
            )
        }

        ObsidianDivider()

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = Obsidian.SpacingMd.dp),
            contentPadding = PaddingValues(bottom = Obsidian.SpacingXxl.dp)
        ) {
            // Section: Made For You
            item {
                ObsidianSectionHeader(title = "Made For You")
                Spacer(modifier = Modifier.height(Obsidian.SpacingXs.dp))
                ObsidianGlassSurface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .padding(horizontal = Obsidian.SpacingLg.dp),
                    cornerRadius = Obsidian.RadiusXxl.dp
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.MusicNote,
                            contentDescription = null,
                            tint = Obsidian.TextTertiary,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.height(Obsidian.SpacingXs.dp))
                        Text(
                            text = "Search a song to start listening",
                            color = Obsidian.TextSecondary,
                            fontSize = 14.sp
                        )
                    }
                }
                Spacer(modifier = Modifier.height(Obsidian.SpacingXl.dp))
            }

            // Section: Your Queue
            item {
                ObsidianSectionHeader(title = "Your Queue")
                Spacer(modifier = Modifier.height(Obsidian.SpacingXs.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = Obsidian.SpacingLg.dp)
                ) {
                    Text(
                        text = "Songs you add to the queue will appear here.",
                        color = Obsidian.TextTertiary,
                        fontSize = 14.sp
                    )
                }
                Spacer(modifier = Modifier.height(Obsidian.SpacingXl.dp))
            }

            // Section: About
            item {
                ObsidianSectionHeader(title = "About")
                Spacer(modifier = Modifier.height(Obsidian.SpacingXs.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = Obsidian.SpacingLg.dp)
                ) {
                    Text(
                        text = "Meowsic is an open-source music player powered by YouTube. " +
                                "Stream any song, build your queue, and enjoy crystal-clear audio \u2014 " +
                                "no subscriptions, no ads.",
                        color = Obsidian.TextTertiary,
                        fontSize = 13.sp,
                        lineHeight = 20.sp
                    )
                }
                Spacer(modifier = Modifier.height(Obsidian.SpacingXl.dp))
            }
        }
    }
}
