package com.surya.meowsic.presentation.library

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.surya.meowsic.ui.components.ObsidianDivider
import com.surya.meowsic.ui.theme.Obsidian

@Composable
fun LibraryScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Obsidian.Background)
            .statusBarsPadding()
    ) {
        // Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = Obsidian.SpacingXl.dp, vertical = Obsidian.SpacingMd.dp)
        ) {
            Text(
                text = "Library",
                color = Obsidian.TextPrimary,
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = (-0.5).sp
            )
        }

        ObsidianDivider()

        // Empty state
        Box(
            modifier = Modifier
                .fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.MusicNote,
                    contentDescription = null,
                    tint = Obsidian.TextTertiary,
                    modifier = Modifier.size(56.dp)
                )
                Spacer(modifier = Modifier.height(Obsidian.SpacingMd.dp))
                Text(
                    text = "Your library is empty",
                    color = Obsidian.TextSecondary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(Obsidian.SpacingXxs.dp))
                Text(
                    text = "Songs you play will appear here.",
                    color = Obsidian.TextTertiary,
                    fontSize = 13.sp
                )
            }
        }
    }
}
