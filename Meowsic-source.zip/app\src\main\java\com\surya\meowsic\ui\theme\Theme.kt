package com.surya.meowsic.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val ObsidianColorScheme = darkColorScheme(
    primary = Color(0xFFFFFFFF),
    onPrimary = Color(0xFF000000),
    primaryContainer = Color(0xFF1C1C1E),
    onPrimaryContainer = Color(0xFFFFFFFF),
    secondary = Color(0xFFA3A3A3),
    onSecondary = Color(0xFF000000),
    secondaryContainer = Color(0xFF101010),
    onSecondaryContainer = Color(0xFFA3A3A3),
    tertiary = Color(0xFF666666),
    onTertiary = Color(0xFFFFFFFF),
    background = Color(0xFF000000),
    onBackground = Color(0xFFFFFFFF),
    surface = Color(0xFF080808),
    onSurface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFF101010),
    onSurfaceVariant = Color(0xFFA3A3A3),
    outline = Color(0xFF1F1F1F),
    outlineVariant = Color(0xFF1A1A1A),
    error = Color(0xFFCF6679),
    onError = Color(0xFF000000)
)

@Composable
fun MeowsicTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ObsidianColorScheme,
        typography = Typography,
        content = content
    )
}
