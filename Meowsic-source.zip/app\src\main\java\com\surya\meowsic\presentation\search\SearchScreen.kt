package com.surya.meowsic.presentation.search

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.surya.meowsic.domain.Song
import com.surya.meowsic.ui.components.ObsidianDivider
import com.surya.meowsic.ui.components.ObsidianSquareArtwork
import com.surya.meowsic.ui.theme.Obsidian
import kotlinx.coroutines.delay

@Composable
fun SearchScreen(
    viewModel: SearchViewModel
) {
    // Local mutable state for the text field — allows instant UI updates while debouncing search
    var searchQuery by remember { mutableStateOf("") }

    val searchResults by viewModel.searchResults.collectAsState()
    val isSearching by viewModel.isSearching.collectAsState()
    val isResolving by viewModel.isResolving.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()
    val currentSong by viewModel.currentSong.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()

    // 500ms debounce: search fires 500ms after the user stops typing
    LaunchedEffect(searchQuery) {
        if (searchQuery.length >= 2) {
            delay(500L)
            viewModel.searchYouTube(searchQuery)
        } else {
            viewModel.searchYouTube(searchQuery) // clears results for short queries
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Obsidian.Background)
            .statusBarsPadding()
    ) {
        // --------------------------------
        // TITLE HEADER
        // --------------------------------
        Text(
            text = "Search",
            color = Obsidian.TextPrimary,
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = (-0.5).sp,
            modifier = Modifier.padding(
                horizontal = Obsidian.SpacingXl.dp,
                vertical = Obsidian.SpacingMd.dp
            )
        )

        // --------------------------------
        // SEARCH INPUT BAR (BasicTextField, Obsidian styled)
        // --------------------------------
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = Obsidian.SpacingXl.dp)
                .height(52.dp)
                .clip(RoundedCornerShape(Obsidian.RadiusMd.dp))
                .background(Obsidian.SurfaceSecondary),
            contentAlignment = Alignment.CenterStart
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = if (searchQuery.isNotEmpty()) Obsidian.TextPrimary else Obsidian.TextTertiary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Box(modifier = Modifier.weight(1f)) {
                    if (searchQuery.isEmpty()) {
                        Text(
                            text = "Songs, artists, channels...",
                            color = Obsidian.TextTertiary,
                            fontSize = 15.sp
                        )
                    }
                    BasicTextField(
                        value = searchQuery,
                        onValueChange = { newValue ->
                            searchQuery = newValue
                            viewModel.onSearchQueryChanged(newValue)
                        },
                        textStyle = TextStyle(
                            color = Obsidian.TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Normal
                        ),
                        cursorBrush = SolidColor(Obsidian.TextPrimary),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                if (searchQuery.isNotEmpty()) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null,
                                onClick = {
                                    searchQuery = ""
                                    viewModel.onSearchQueryChanged("")
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Clear,
                            contentDescription = "Clear",
                            tint = Obsidian.TextTertiary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(Obsidian.SpacingXs.dp))

        // --------------------------------
        // SEARCH LOADING INDICATOR
        // --------------------------------
        AnimatedVisibility(
            visible = isSearching,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            LinearProgressIndicator(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = Obsidian.SpacingXl.dp)
                    .height(2.dp)
                    .clip(RoundedCornerShape(1.dp)),
                color = Obsidian.TextPrimary,
                trackColor = Obsidian.SurfaceHighlight
            )
        }

        // --------------------------------
        // RESOLVING BANNER
        // --------------------------------
        AnimatedVisibility(
            visible = isResolving && currentSong != null,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = Obsidian.SpacingXl.dp, vertical = Obsidian.SpacingXxs.dp)
                    .clip(RoundedCornerShape(Obsidian.RadiusMd.dp))
                    .background(Obsidian.SurfaceElevated)
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(16.dp),
                    color = Obsidian.TextPrimary,
                    strokeWidth = 2.dp
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "Preparing ${currentSong?.title ?: ""}...",
                    color = Obsidian.TextSecondary,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        // --------------------------------
        // ERROR BANNER
        // --------------------------------
        errorMessage?.let { error ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = Obsidian.SpacingXl.dp, vertical = Obsidian.SpacingXxs.dp)
                    .clip(RoundedCornerShape(Obsidian.RadiusMd.dp))
                    .background(Color(0xFF1A0808))
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = error,
                    color = Color(0xFFCF6679),
                    fontSize = 13.sp,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { viewModel.clearError() }) {
                    Text("Dismiss", color = Obsidian.TextSecondary, fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(Obsidian.SpacingXs.dp))

        ObsidianDivider()

        // --------------------------------
        // EMPTY STATE OR RESULTS
        // --------------------------------
        if (searchResults.isEmpty() && searchQuery.isBlank()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.MusicNote,
                        contentDescription = null,
                        tint = Obsidian.TextDisabled,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(Obsidian.SpacingMd.dp))
                    Text(
                        text = "Find your favorite songs and artists",
                        color = Obsidian.TextTertiary,
                        fontSize = 15.sp
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(bottom = 8.dp)
            ) {
                items(
                    items = searchResults,
                    key = { song -> song.id }
                ) { song ->
                    val isCurrent = currentSong?.id == song.id
                    val isSongResolving = isCurrent && isResolving
                    val isSongPlaying = isCurrent && isPlaying

                    ObsidianSongItem(
                        song = song,
                        isCurrent = isCurrent,
                        isResolving = isSongResolving,
                        isPlaying = isSongPlaying,
                        onClick = {
                            if (isCurrent) {
                                viewModel.togglePlayPause()
                            } else {
                                viewModel.playSong(song, playlist = searchResults)
                            }
                        }
                    )
                    ObsidianDivider(
                        modifier = Modifier.padding(horizontal = Obsidian.SpacingXl.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ObsidianSongItem(
    song: Song,
    isCurrent: Boolean = false,
    isResolving: Boolean = false,
    isPlaying: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .padding(
                horizontal = Obsidian.SpacingXl.dp,
                vertical = Obsidian.SpacingSm.dp
            ),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Thumbnail
        Box(contentAlignment = Alignment.Center) {
            ObsidianSquareArtwork(
                imageUrl = song.thumbnailUrl,
                size = 52.dp,
                cornerRadius = 10.dp,
                contentDescription = song.title
            )
            // Playing overlay on artwork
            if (isSongPlaying(isCurrent, isPlaying, isResolving)) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.Black.copy(alpha = 0.4f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.MusicNote,
                        contentDescription = "Playing",
                        tint = Obsidian.TextPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.width(Obsidian.SpacingSm.dp))

        // Song details
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = song.title,
                color = if (isCurrent) Obsidian.TextPrimary else Obsidian.TextPrimary,
                fontSize = 15.sp,
                fontWeight = if (isCurrent) FontWeight.SemiBold else FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = song.artist,
                color = Obsidian.TextSecondary,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(modifier = Modifier.width(Obsidian.SpacingXs.dp))

        // Status icon
        if (isResolving) {
            CircularProgressIndicator(
                modifier = Modifier.size(20.dp),
                color = Obsidian.TextPrimary,
                strokeWidth = 2.dp
            )
        } else if (isCurrent) {
            Icon(
                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = if (isPlaying) "Pause" else "Play",
                tint = Obsidian.TextPrimary,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

private fun isSongPlaying(isCurrent: Boolean, isPlaying: Boolean, isResolving: Boolean): Boolean {
    return isCurrent && isPlaying && !isResolving
}
