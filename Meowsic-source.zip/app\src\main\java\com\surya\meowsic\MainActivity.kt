package com.surya.meowsic

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.surya.meowsic.data.stream.YouTubeStreamResolver
import com.surya.meowsic.presentation.home.HomeScreen
import com.surya.meowsic.presentation.library.LibraryScreen
import com.surya.meowsic.presentation.player.FullScreenPlayer
import com.surya.meowsic.presentation.player.MiniPlayer
import com.surya.meowsic.presentation.search.SearchScreen
import com.surya.meowsic.presentation.search.SearchViewModel
import com.surya.meowsic.ui.theme.LiquidGlassTokens
import com.surya.meowsic.ui.theme.MeowsicTheme
import com.surya.meowsic.ui.theme.Obsidian

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Authoritative NewPipe initialization (single-point initialization)
        YouTubeStreamResolver.initialize()

        setContent {
            MeowsicTheme {
                MeoMusicApp()
            }
        }
    }
}

@Composable
fun MeoMusicApp(
    searchViewModel: SearchViewModel = viewModel()
) {
    var selectedTab by remember { mutableIntStateOf(0) } // Default to Home tab
    val isFullScreenPlayerOpen by searchViewModel.isFullScreenOpen.collectAsState()
    val currentSong by searchViewModel.currentSong.collectAsState()

    // Handle back button to collapse full-screen player when visible
    BackHandler(enabled = isFullScreenPlayerOpen) {
        searchViewModel.closeFullScreen()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Obsidian.Background)
    ) {
        Scaffold(
            containerColor = Obsidian.Background,
            bottomBar = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                ) {
                    // Floating Mini-Player
                    MiniPlayer(
                        viewModel = searchViewModel,
                        onOpenFullScreen = { searchViewModel.openFullScreen() }
                    )

                    // Obsidian Navigation Bar
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                            .clip(RoundedCornerShape(24.dp))
                            .background(Obsidian.SurfaceElevated)
                    ) {
                        NavigationBar(
                            containerColor = Color.Transparent,
                            tonalElevation = 0.dp,
                            modifier = Modifier.height(64.dp)
                        ) {
                            val items = listOf("Home", "Search", "Library")
                            val icons = listOf(
                                Icons.Default.Home,
                                Icons.Default.Search,
                                Icons.Default.LibraryMusic
                            )

                            items.forEachIndexed { index, title ->
                                val isSelected = selectedTab == index
                                NavigationBarItem(
                                    selected = isSelected,
                                    onClick = { selectedTab = index },
                                    icon = {
                                        Icon(
                                            icons[index],
                                            contentDescription = title,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = title,
                                            fontSize = 11.sp,
                                            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Obsidian.TextPrimary,
                                        selectedTextColor = Obsidian.TextPrimary,
                                        indicatorColor = Obsidian.SurfaceHighlight,
                                        unselectedIconColor = Obsidian.TextTertiary,
                                        unselectedTextColor = Obsidian.TextTertiary
                                    )
                                )
                            }
                        }
                    }
                }
            }
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                when (selectedTab) {
                    0 -> HomeScreen()
                    1 -> SearchScreen(viewModel = searchViewModel)
                    2 -> LibraryScreen()
                }
            }
        }

        // Full-screen AMOLED player
        AnimatedVisibility(
            visible = isFullScreenPlayerOpen && currentSong != null,
            enter = slideInVertically(
                initialOffsetY = { it },
                animationSpec = LiquidGlassTokens.SlideSpringSpec
            ),
            exit = slideOutVertically(
                targetOffsetY = { it },
                animationSpec = LiquidGlassTokens.SlideSpringSpec
            ),
            modifier = Modifier.fillMaxSize()
        ) {
            FullScreenPlayer(
                viewModel = searchViewModel,
                onDismiss = { searchViewModel.closeFullScreen() }
            )
        }
    }
}
